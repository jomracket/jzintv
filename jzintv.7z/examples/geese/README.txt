This is a demonstration of Geese wandering around, inspired by 
Richard A. Worthington's Goose Attack! game concept posted to INTVPROG.



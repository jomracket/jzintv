This is a canonical "Hello World" example.


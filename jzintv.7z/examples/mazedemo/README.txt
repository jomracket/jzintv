MAZEDEMO

This is one of the first demos I (Joe Zbiciak) wrote when I was first
learning the Intellivision.

This demo uses the Colored Squares mode.  It draws a sequence of mazes
onscreen.  It takes no user input beyond the title screen.

